﻿/*
	TUIO C# Demo - part of the reacTIVision project
	Copyright (c) 2005-2016 Martin Kaltenbrunner <martin@tuio.org>

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

using System;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel;
using System.Collections.Generic;
using System.Collections;
using System.Threading;
using TUIO;
using System.IO;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
public class TuioDemo : Form, TuioListener
{
	private TuioClient client;
	private Dictionary<long, TuioObject> objectList;
	private Dictionary<long, TuioCursor> cursorList;
	private Dictionary<long, TuioBlob> blobList;
	private TuioCursor lastCursor;  // Variable to store the last known cursor
	private TuioObject lastObject;

	public static int width, height;
	private int window_width = 640;
	private int window_height = 480;
	private int window_left = 0;
	private int window_top = 0;
	private int screen_width = Screen.PrimaryScreen.Bounds.Width;
	private int screen_height = Screen.PrimaryScreen.Bounds.Height;

	private bool fullscreen;
	private bool verbose;
	private int latestId;

	Font font = new Font("Arial", 10.0f);
	SolidBrush fntBrush = new SolidBrush(Color.White);
	SolidBrush bgrBrush = new SolidBrush(Color.FromArgb(0, 0, 64));
	SolidBrush curBrush = new SolidBrush(Color.FromArgb(192, 0, 192));
	SolidBrush objBrush = new SolidBrush(Color.FromArgb(64, 0, 0));
	SolidBrush blbBrush = new SolidBrush(Color.FromArgb(64, 64, 64));
	Pen curPen = new Pen(new SolidBrush(Color.Blue), 1);
    private string lastCursorText;
    private Image lastCursorImage;
    private string lastObjectText;
    private Image lastObjectImage;
    private Point lastObjectPosition = Point.Empty;
    List<string> imagePaths = new List<string> { "Sunblock.png", "dermatique1.png", "dermatique1.png" };
    int imageStartX = width - 100;
    int imageStartY = 150;
    int imageWidth = 100;
    int imageHeight = 100;
    List<Tuple<Rectangle, Rectangle>> productRectangles = new List<Tuple<Rectangle, Rectangle>>();
    string backgroundPath = "Untitled design (3).png";
    public TuioDemo(int port) {

        verbose = false;
        fullscreen = true;

        // Set the form to be borderless and maximized
        //this.FormBorderStyle = FormBorderStyle.None;
        this.WindowState = FormWindowState.Maximized;

        // Set ClientSize to match screen resolution
        width = Screen.PrimaryScreen.Bounds.Width;
        height = Screen.PrimaryScreen.Bounds.Height;
        this.ClientSize = new System.Drawing.Size(width, height);
        this.Name = "TuioDemo";
		this.Text = "TuioDemo";
            this.BackColor = Color.White;

		this.Closing += new CancelEventHandler(Form_Closing);
		this.KeyDown += new KeyEventHandler(Form_KeyDown);

		this.SetStyle(ControlStyles.AllPaintingInWmPaint |
						ControlStyles.UserPaint |
						ControlStyles.DoubleBuffer, true);

		objectList = new Dictionary<long, TuioObject>(128);
		cursorList = new Dictionary<long, TuioCursor>(128);
		blobList = new Dictionary<long, TuioBlob>(128);

		client = new TuioClient(port);
		client.addTuioListener(this);

		client.connect();
	}

	private void Form_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e) {

		if (e.KeyData == Keys.F1) {
			if (fullscreen == false) {

				width = screen_width;
				height = screen_height;

				window_left = this.Left;
				window_top = this.Top;

				this.FormBorderStyle = FormBorderStyle.None;
				this.Left = 0;
				this.Top = 0;
				this.Width = screen_width;
				this.Height = screen_height;

				fullscreen = true;
			} else {

				width = window_width;
				height = window_height;

				this.FormBorderStyle = FormBorderStyle.Sizable;
				this.Left = window_left;
				this.Top = window_top;
				this.Width = window_width;
				this.Height = window_height;

				fullscreen = false;
			}
		} else if (e.KeyData == Keys.Escape) {
			this.Close();

		} else if (e.KeyData == Keys.V) {
			verbose = !verbose;
		}

	}

	private void Form_Closing(object sender, System.ComponentModel.CancelEventArgs e)
	{
		client.removeTuioListener(this);

		client.disconnect();
		System.Environment.Exit(0);
	}

	public void addTuioObject(TuioObject o) {
		lock (objectList) {
			objectList.Add(o.SessionID, o);
		} if (verbose) Console.WriteLine("add obj " + o.SymbolID + " (" + o.SessionID + ") " + o.X + " " + o.Y + " " + o.Angle);
	}

	public void updateTuioObject(TuioObject o) {

		if (verbose) Console.WriteLine("set obj " + o.SymbolID + " " + o.SessionID + " " + o.X + " " + o.Y + " " + o.Angle + " " + o.MotionSpeed + " " + o.RotationSpeed + " " + o.MotionAccel + " " + o.RotationAccel);
	}

	public void removeTuioObject(TuioObject o) {
		lock (objectList) {
			objectList.Remove(o.SessionID);
		}
		if (verbose) Console.WriteLine("del obj " + o.SymbolID + " (" + o.SessionID + ")");
	}

	public void addTuioCursor(TuioCursor c) {
		lock (cursorList) {
			cursorList.Add(c.SessionID, c);
		}
		if (verbose) Console.WriteLine("add cur " + c.CursorID + " (" + c.SessionID + ") " + c.X + " " + c.Y);
	}

	public void updateTuioCursor(TuioCursor c) {
		if (verbose) Console.WriteLine("set cur " + c.CursorID + " (" + c.SessionID + ") " + c.X + " " + c.Y + " " + c.MotionSpeed + " " + c.MotionAccel);
	}

	public void removeTuioCursor(TuioCursor c) {
		lock (cursorList) {
			cursorList.Remove(c.SessionID);
		}
		if (verbose) Console.WriteLine("del cur " + c.CursorID + " (" + c.SessionID + ")");
	}

	public void addTuioBlob(TuioBlob b) {
		lock (blobList) {
			blobList.Add(b.SessionID, b);
		}
		if (verbose) Console.WriteLine("add blb " + b.BlobID + " (" + b.SessionID + ") " + b.X + " " + b.Y + " " + b.Angle + " " + b.Width + " " + b.Height + " " + b.Area);
	}

	public void updateTuioBlob(TuioBlob b) {

		if (verbose) Console.WriteLine("set blb " + b.BlobID + " (" + b.SessionID + ") " + b.X + " " + b.Y + " " + b.Angle + " " + b.Width + " " + b.Height + " " + b.Area + " " + b.MotionSpeed + " " + b.RotationSpeed + " " + b.MotionAccel + " " + b.RotationAccel);
	}

	public void removeTuioBlob(TuioBlob b) {
		lock (blobList) {
			blobList.Remove(b.SessionID);
		}
		if (verbose) Console.WriteLine("del blb " + b.BlobID + " (" + b.SessionID + ")");
	}

	public void refresh(TuioTime frameTime) {
		Invalidate();
	}

	private void DrawProductDetails(Graphics g, TuioObject tobj, PointF location, Color textColor)
	{
		// Sample product details (you can replace this with dynamic data)
		List<string> productDetails = new List<string>
	{
		"Brand: Dermatique",
		"Type: Purifying Cleansing Gel",
		"Volume: 150ml",
		"Features: Deep cleansing, suitable for all skin types",
		"Price: $15.99",
		"Usage: Apply a small amount to wet skin, massage, and rinse."
	};

		// Set the starting position for drawing the details
		float yOffset = 0;

		// Use the provided color for the text
		using (Brush textBrush = new SolidBrush(textColor))
		{
			foreach (var detail in productDetails)
			{
				g.DrawString($"• {detail}", font, textBrush, new PointF(location.X, location.Y + yOffset));
				yOffset += font.GetHeight(g) + 2; // Adjust vertical spacing between lines
			}
		}
	}
    private void drawmenu()
    {
        if (productRectangles.Count == 0) // Only initialize if not already populated
        {
            int startX = 230;
            int spacing = 100;

            for (int i = 0; i < imagePaths.Count; i++)
            {
                if (File.Exists(imagePaths[i]))
                {
                    // Calculate space for centering
                    int totalHeight = 500; // Total height for product rectangle and pink section
                    int topOffset = (height - totalHeight) / 2; // Center vertically based on available space

                    // Create the main product display rectangle
                    Rectangle productRect = new Rectangle(startX, topOffset, 300, 450); // Adjusted for desired width and height
                    Rectangle bottomTextRect = new Rectangle(productRect.X, productRect.Bottom - 50, productRect.Width, 50); // Pink section below product

                    // Store the rectangles in the list
                    productRectangles.Add(new Tuple<Rectangle, Rectangle>(productRect, bottomTextRect));

                    // Increment X for next product rectangle
                    startX += productRect.Width + spacing;
                }
            }
        }

        

    }

    protected override void OnPaintBackground(PaintEventArgs pevent)
    {
        drawmenu();
        // Getting the graphics object
        Graphics g = pevent.Graphics;
        int start=(height/3)-30;
        // Draw the background image if it exists
        string backgroundImagePath = "home.png";
        if (File.Exists(backgroundImagePath))
        {
            using (Image bgImage = Image.FromFile(backgroundImagePath))
            {
                g.DrawImage(bgImage, new Rectangle(0, 0, width, height));
            }
        }
        using (Font titleFont = new Font("Verdana", 24, FontStyle.Bold))
        using (SolidBrush titleBrush = new SolidBrush(Color.Purple))
        {
            g.DrawString("Pharmacy Shop", titleFont, titleBrush, new Point(50, start));
        }
        start += 80;
        // Draw description text
        using (Font descFont = new Font("Verdana", 12))
        using (SolidBrush descBrush = new SolidBrush(Color.Gray))
        {
            g.DrawString("Experience convenient pharmacy ", descFont, descBrush, new RectangleF(50, start, 700, 50));
            start += 30;
            g.DrawString  ("shopping with fast delivery.", descFont, descBrush, new RectangleF(50, start, 700, 50));
            start += 30;

            g.DrawString("Get your essentials with a click!", descFont, descBrush, new RectangleF(50, start, 700, 30));

        }
        start += 80;
        // Draw 'Shop Now' button
        Rectangle buttonRect = new Rectangle(50, start, 180, 40); // Reduced width and height, adjusted Y location
        using (GraphicsPath path = new GraphicsPath())
        {
            path.AddArc(buttonRect.X, buttonRect.Y, 40, 40, 180, 90);
            path.AddArc(buttonRect.X + buttonRect.Width - 40, buttonRect.Y, 40, 40, 270, 90);
            path.AddArc(buttonRect.X + buttonRect.Width - 40, buttonRect.Y + buttonRect.Height - 40, 40, 40, 0, 90);
            path.AddArc(buttonRect.X, buttonRect.Y + buttonRect.Height - 40, 40, 40, 90, 90);
            path.CloseAllFigures();

            using (SolidBrush buttonBrush = new SolidBrush(Color.Purple))
            {
                g.FillPath(buttonBrush, path);
            }
            using (Pen borderPen = new Pen(Color.DarkMagenta, 6)) // Adjusted border width
            {
                g.DrawPath(borderPen, path);
            }
            using (Font buttonFont = new Font("Verdana", 16, FontStyle.Bold))
            using (SolidBrush buttonTextBrush = new SolidBrush(Color.White))
            {
                SizeF textSize = g.MeasureString("Shop Now", buttonFont);
                PointF textLocation = new PointF(
                    buttonRect.X + (buttonRect.Width - textSize.Width+10) / 2,
                    buttonRect.Y + (buttonRect.Height - textSize.Height) / 2
                );
                g.DrawString("Shop Now", buttonFont, buttonTextBrush, textLocation);
            }
        }
        // Draw the cursor path if available
        if (cursorList.Count > 0)
        {
            lock (cursorList)
            {
                foreach (TuioCursor tcur in cursorList.Values)
                {
                    List<TuioPoint> path = tcur.Path;
                    TuioPoint current_point = path[0];

                    for (int i = 1; i < path.Count; i++)
                    {
                        TuioPoint next_point = path[i];
                        g.DrawLine(curPen, current_point.getScreenX(width), current_point.getScreenY(height), next_point.getScreenX(width), next_point.getScreenY(height));
                        current_point = next_point;
                    }
                    g.FillEllipse(curBrush, current_point.getScreenX(width) - height / 100, current_point.getScreenY(height) - height / 100, height / 50, height / 50);
                    g.DrawString(tcur.CursorID.ToString(), font, fntBrush, new PointF(current_point.getScreenX(width) - 10, current_point.getScreenY(height) - 10));
                }
            }
        }

        // Draw the objects if they are detected
        if (objectList.Count > 0)
        {
            lock (objectList)
            {
                foreach (TuioObject tobj in objectList.Values)
                {
                    int ox = tobj.getScreenX(width);
                    int oy = tobj.getScreenY(height);
                    int size = height / 10;
                    latestId = tobj.SymbolID;

                    if (tobj.SymbolID == 0)
                    {
                        try
                        {
                            Bitmap background = new Bitmap("background.jpg");
                            g.DrawImage(background, new Rectangle(0, 0, width, height));
                            Bitmap dermatiqueImage = new Bitmap("dermatique.jpg");
                            dermatiqueImage.MakeTransparent(dermatiqueImage.GetPixel(0, 0));
                            lastObjectImage = dermatiqueImage;

                            int staticX = width / 2 - 80;
                            int staticY = height / 2 - 100;
                            int newSize = size * 4;

                            g.DrawImage(lastObjectImage, new Rectangle(staticX - newSize / 2, staticY - newSize / 2, newSize, newSize));

                            string displayText = "Dermatique Facial Wash";
                            Color textColor = Color.Green;
                            using (Brush textBrush = new SolidBrush(textColor))
                            {
                                g.DrawString(displayText, font, textBrush, new PointF(staticX - 20, staticY + newSize / 2 + 10));
                            }

                            PointF detailsLocation = new PointF(staticX - 20, staticY + newSize / 2 + 30);
                            DrawProductDetails(g, tobj, detailsLocation, textColor);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("Error drawing object image: " + ex.Message);
                        }
                    }
					else if(tobj.SymbolID == 1)
					{
						try
						{
                            Bitmap backImage = new Bitmap("podium-brown-product-display-background-3d-illustration-empty-display-scene-presentation-product-placement.jpg");
                            Bitmap product = new Bitmap("product2-removebg-preview.png");

                            product.MakeTransparent(product.GetPixel(0, 0));
                            lastObjectImage = product;
                            g.DrawImage(backImage, new Rectangle(0, 0, width, height));
                            g.DrawImage(product, new Rectangle(width - product.Width - 180, height - product.Height - 63, product.Width, product.Height - 30));

                            Font fontTitle = new Font("Arial", 10, FontStyle.Bold);
                            Font fontSubtitle = new Font("Arial", 10, FontStyle.Regular);
                            Brush textBrush = new SolidBrush(Color.Black);
                            Color customColor = Color.FromArgb(172, 96, 47);
                            Pen pen = new Pen(customColor, 3);
                            Pen pen2 = new Pen(customColor, 4);

                            g.TextRenderingHint = TextRenderingHint.AntiAlias;

                            int startX = 20;
                            int startY = 90;
                            int lineLength = 200;
                            int lineSpacing = 60;
                            int lineOffsetY = 25;


                            g.DrawString("Highest Protection SPF50+", fontTitle, textBrush, new PointF(startX, startY));
                            g.DrawLine(pen, startX, startY + lineOffsetY, startX + lineLength, startY + lineOffsetY);
                            g.FillEllipse(new SolidBrush(customColor), startX + lineLength, startY + lineOffsetY - 5, 10, 10);
                            startY += lineSpacing;
                            g.DrawString("Light, fast-absorbing formula", fontTitle, textBrush, new PointF(startX, startY));
                            g.DrawLine(pen, startX, startY + lineOffsetY, startX + lineLength, startY + lineOffsetY);
                            g.FillEllipse(new SolidBrush(customColor), startX + lineLength, startY + lineOffsetY - 5, 10, 10);

                            startY += lineSpacing;
                            g.DrawString("Pollution Protection Technology", fontTitle, textBrush, new PointF(startX, startY));
                            g.DrawLine(pen, startX, startY + lineOffsetY, startX + lineLength, startY + lineOffsetY);
                            g.FillEllipse(new SolidBrush(customColor), startX + lineLength, startY + lineOffsetY - 5, 10, 10);

                           

                            Font fontPrice = new Font("Arial", 14, FontStyle.Bold);
                            Brush shadowBrush = new SolidBrush(Color.FromArgb(128, 0, 0, 0));
                            g.FillRectangle(new SolidBrush(customColor), width - 100, -2, 60, 100);
                            g.DrawString("$500", fontPrice, shadowBrush, width - 95, 70);

                        }
						catch (Exception ex)
                        {
                            Console.WriteLine("Error drawing object image: " + ex.Message);

                        }


                    }
                    else if (tobj.SymbolID == 2)
                    {
                        try
                        {
                            Bitmap Product123 = new Bitmap("123.jpg");
                            Bitmap BK = new Bitmap("BK.jpg");

                            Product123.MakeTransparent(Product123.GetPixel(0, 0));


                            lastObjectImage = Product123;
                            g.DrawImage(BK, new Rectangle(0, 0, width, height));
                            g.DrawImage(Product123, new Rectangle(width / 2 - 280, height /2 - 250, width/2 + 20, height/2 + 100));


                            Font font = new Font("Times New Roman", 13, FontStyle.Bold);
                            Brush textBrush = new SolidBrush(Color.Blue);
                            
               
                            int startX = 30;
                            int startY = 300;



                            float desc = 500;
                            g.DrawString($"• Medical Description: Used in the treatment of fever and headache associated with common cold, nasal congestion, sinus pain and congestion, " +
                                         "runny nose, sneezing, and itching of the nose and throat.", font, textBrush,
                                         new RectangleF(startX, startY, desc, 100));


                            startY += 90;
                            g.DrawString($"• Suitable For: Adult over 12 years old.", font, textBrush, new PointF(startX, startY));
                            startY += 50;
                            g.DrawString($"• Price: 25 EGP.", font, textBrush, new PointF(startX, startY));


                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("Error drawing object image: " + ex.Message);

                        }

                    }
                    else if(tobj.SymbolID == 3) //to show info of dermatique sunblock
                    {
                        try
                        {
                           
                            if (File.Exists(backgroundPath))
                            {
                                using (Image backgroundImg = Image.FromFile(backgroundPath))
                                {
                                    g.DrawImage(backgroundImg, new Rectangle(0, 0, width, height));
                                }
                            }
                         
                            Rectangle rect = new Rectangle(150, 165, 400, 500); // Adjust position and size as needed
                            Color rectColor = Color.FromArgb(255, 234, 233, 239);// Replace with DarkGray RGB values or another color
                            int cornerRadius = 20; // Corner radius for rounded corners fvgbhjk;'0`1                            DrawRoundedRectangle(g, rect,rectColor, 20, Color.FromArgb(255,255, 178, 34));
                            DrawRoundedRectangle(g, rect, rectColor, cornerRadius, Color.FromArgb(255, 255, 178, 34),1);
                            string[] sentences = {
                                "This is the first sentence that spans across three lines for layout testing purposes.",
                                "Here is the second sentence, carefully crafted to ensure it also takes three lines.",
                                "Finally, this is the third sentence, with enough words to stretch into three lines.",
                                "This is an additional sentence to ensure the rectangle holds more text and stays balanced."
                            };

                            Rectangle rect2 = new Rectangle(150, 165, 400, 500);
                            Font textFont = new Font("Arial", 14, FontStyle.Regular);
                            Brush textBrush = new SolidBrush(Color.FromArgb(100, 100, 100)); // Darker gray text color
                            int verticalPadding = 95;
                            int horizontalPadding = 20;
                            int lineSpacing = 20;
                            DrawTextBlock(g, rect2, sentences, textFont, textBrush, verticalPadding, horizontalPadding, lineSpacing);

                            if (File.Exists(imagePaths[0]))
                            {
                                using (Image img = Image.FromFile(imagePaths[0]))
                                {
                                    g.DrawImage(img, new Rectangle(width-600, 50, 400, 600));
                                    
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("Error drawing object image: " + ex.Message);

                        }
                    }
                    else if(tobj.SymbolID==4) //button to view menu of items
                    {
                        try
                        {

                           
                            if (File.Exists(backgroundPath))
                            {
                                using (Image backgroundImg = Image.FromFile(backgroundPath))
                                {
                                    g.DrawImage(backgroundImg, new Rectangle(0, 0, width, height));
                                }
                            }

                            for (int i = 0; i < productRectangles.Count; i++)
                            {
                                // Draw the main product display rectangle with rounded corners
                                Rectangle productRect = productRectangles[i].Item1;
                                Color productRectColor = Color.FromArgb(255, 234, 233, 239);
                                int cornerRadius = 50; // Circular corners
                                DrawRoundedRectangle(g, productRect, productRectColor, cornerRadius, productRectColor, 0); // Removed border

                                // Draw the product image inside the rectangle
                                if (File.Exists(imagePaths[i]))
                                {
                                    using (Image productImg = Image.FromFile(imagePaths[i]))
                                    {
                                       // Adjusted position for better alignment
                                        if(i==0)
                                        {
                                            int imgX = (productRect.X + (productRect.Width - 200) / 2)-40; // Center the image
                                            int imgY = productRect.Y -20;
                                            g.DrawImage(productImg, new Rectangle(imgX, imgY, 280, 400));

                                        }
                                        else
                                        {
                                            int imgX = productRect.X + (productRect.Width - 200) / 2; // Center the image
                                            int imgY = productRect.Y + 20;
                                            g.DrawImage(productImg, new Rectangle(imgX, imgY, 200, 350));
                                        }
                                       // Adjusted product image size
                                    }
                                }

                                // Draw the pink section at the bottom
                                Rectangle bottomTextRect = productRectangles[i].Item2;
                                using (SolidBrush pinkBrush = new SolidBrush(Color.FromArgb(255, 254, 81, 161)))
                                {
                                    g.FillRectangle(pinkBrush, bottomTextRect);
                                }

                                // Draw text inside the pink section
                                string bottomText = "Product Details Here";
                                using (Font textFont = new Font("Arial", 14, FontStyle.Bold))
                                using (Brush textBrush = new SolidBrush(Color.White))
                                {
                                    SizeF textSize = g.MeasureString(bottomText, textFont);
                                    PointF textLocation = new PointF(
                                        bottomTextRect.X + (bottomTextRect.Width - textSize.Width) / 2,
                                        bottomTextRect.Y + (bottomTextRect.Height - textSize.Height) / 2
                                    );
                                    g.DrawString(bottomText, textFont, textBrush, textLocation);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("Error drawing object image: " + ex.Message);

                        }
                    }
                    else
                    {
                        g.FillRectangle(Brushes.Blue, new Rectangle(ox - size / 2, oy - size / 2, size, size));
                        g.DrawString($"ID: {tobj.SymbolID}", font, Brushes.White, new PointF(ox - size / 2 + 5, oy - size / 2 + 5));

                        lastObjectImage = null; 
                        latestId = tobj.SymbolID;
                        lastObjectPosition = new Point(ox, oy);
                    }
                }
            }
        }

        // Draw the last known object image and details if no object is detected
        if (objectList.Count == 0)
        {
            if (latestId == 0 && lastObjectImage != null)
            {
                try
                {
                    Bitmap background = new Bitmap("background.jpg");
                    g.DrawImage(background, new Rectangle(0, 0, width, height));
                    int staticX = width / 2 - 80;
                    int staticY = height / 2 - 100;
                    int newSize = height / 10 * 4;

                    g.DrawImage(lastObjectImage, new Rectangle(staticX - newSize / 2, staticY - newSize / 2, newSize, newSize));
                    
                    string lastDisplayText = "Dermatique Facial Wash";
                    Color lastTextColor = Color.Green;
                    using (Brush lastTextBrush = new SolidBrush(lastTextColor))
                    {
                        g.DrawString(lastDisplayText, font, lastTextBrush, new PointF(staticX - 20, staticY + newSize / 2 + 10));
                    }

                    PointF lastDetailsLocation = new PointF(staticX - 20, staticY + newSize / 2 + 30);
                    DrawProductDetails(g, null, lastDetailsLocation, lastTextColor);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error drawing last known object image: " + ex.Message);
                }
            }
            else  if (latestId == 1 && lastObjectImage != null)
            {
                try
                {
                    Bitmap backImage = new Bitmap("podium-brown-product-display-background-3d-illustration-empty-display-scene-presentation-product-placement.jpg");
                    Bitmap product = new Bitmap("product2-removebg-preview.png");

                    product.MakeTransparent(product.GetPixel(0, 0));

                    g.DrawImage(backImage, new Rectangle(0, 0, width, height));
                    g.DrawImage(product, new Rectangle(width - product.Width - 180, height - product.Height - 63, product.Width, product.Height - 30));

                    Font fontTitle = new Font("Arial", 10, FontStyle.Bold);
                    Font fontSubtitle = new Font("Arial", 10, FontStyle.Regular);
                    Brush textBrush = new SolidBrush(Color.Black);
                    Color customColor = Color.FromArgb(172, 96, 47);
                    Pen pen = new Pen(customColor, 3);
                    Pen pen2 = new Pen(customColor, 4);

                    g.TextRenderingHint = TextRenderingHint.AntiAlias;

                    int startX = 20;
                    int startY = 90;
                    int lineLength = 200;
                    int lineSpacing = 60;
                    int lineOffsetY = 25;


                    g.DrawString("Highest Protection SPF50+", fontTitle, textBrush, new PointF(startX, startY));
                    g.DrawLine(pen, startX, startY + lineOffsetY, startX + lineLength, startY + lineOffsetY);
                    g.FillEllipse(new SolidBrush(customColor), startX + lineLength, startY + lineOffsetY - 5, 10, 10);
                    startY += lineSpacing;
                    g.DrawString("Light, fast-absorbing formula", fontTitle, textBrush, new PointF(startX, startY));
                    g.DrawLine(pen, startX, startY + lineOffsetY, startX + lineLength, startY + lineOffsetY);
                    g.FillEllipse(new SolidBrush(customColor), startX + lineLength, startY + lineOffsetY - 5, 10, 10);

                    startY += lineSpacing;
                    g.DrawString("Pollution Protection Technology", fontTitle, textBrush, new PointF(startX, startY));
                    g.DrawLine(pen, startX, startY + lineOffsetY, startX + lineLength, startY + lineOffsetY);
                    g.FillEllipse(new SolidBrush(customColor), startX + lineLength, startY + lineOffsetY - 5, 10, 10);

                    //int circleX = 400;
                    //int circleY = 200;  
                    //int circleDiameter = 70;

                    //  g.DrawEllipse(new Pen(Color.White,3), circleX, circleY, circleDiameter, circleDiameter);
                    // g.FillEllipse(new SolidBrush(Color.SandyBrown), circleX, circleY, circleDiameter, circleDiameter);

                    Font fontPrice = new Font("Arial", 14, FontStyle.Bold);
                    int shadowOffsetX = 3;
                    int shadowOffsetY = 3;

                    Brush shadowBrush = new SolidBrush(Color.FromArgb(128, 0, 0, 0));

                    // g.DrawString("$500", fontPrice, shadowBrush, new PointF(circleX + 10 + shadowOffsetX, circleY + 22 + shadowOffsetY));

                    // g.DrawString("$500", fontPrice, new SolidBrush(Color.White), new PointF(circleX + 10, circleY + 22));
                    g.FillRectangle(new SolidBrush(customColor), width - 100, -2, 60, 100);
                    g.DrawString("$500", fontPrice, shadowBrush, width - 95, 70);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error drawing last known object image: " + ex.Message);
                }
            }
            else if (latestId == 2 && lastObjectImage != null)
            {
                try
                {
                    Bitmap Product123 = new Bitmap("123.jpg");
                    Bitmap BK = new Bitmap("BK.jpg");

                    Product123.MakeTransparent(Product123.GetPixel(0, 0));


                    lastObjectImage = Product123;
                    g.DrawImage(BK, new Rectangle(0, 0, width, height));
                    g.DrawImage(Product123, new Rectangle(width / 2 - 280, height / 2 - 250, width / 2 + 20, height / 2 + 100));


                    Font font = new Font("Times New Roman", 13, FontStyle.Bold);
                    Brush textBrush = new SolidBrush(Color.Blue);


                    int startX = 30;
                    int startY = 300;
                    float desc = 500;
                    g.DrawString($"• Medical Description: Used in the treatment of fever and headache associated with common cold, nasal congestion, sinus pain and congestion, " +
                                 "runny nose, sneezing, and itching of the nose and throat.", font, textBrush,
                                 new RectangleF(startX, startY, desc, 100));


                    startY += 90;
                    g.DrawString($"• Suitable For: Adult over 12 years old.", font, textBrush, new PointF(startX, startY));
                    startY += 50;
                    g.DrawString($"• Price: 25 EGP.", font, textBrush, new PointF(startX, startY));
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error drawing object image: " + ex.Message);

                }
            }
            else if (latestId != 0)
            {
                g.FillRectangle(Brushes.Blue, new Rectangle(lastObjectPosition.X - 30, lastObjectPosition.Y - 30, 60, 60));
                g.DrawString($"ID: {latestId}", font, Brushes.White, new PointF(lastObjectPosition.X - 25, lastObjectPosition.Y - 25));
            }
        }
    

    

        // Draw the blobs
        if (blobList.Count > 0)
		{
			lock (blobList)
			{
				foreach (TuioBlob tblb in blobList.Values)
				{
					int bx = tblb.getScreenX(width);
					int by = tblb.getScreenY(height);
					float bw = tblb.Width * width;
					float bh = tblb.Height * height;

					g.TranslateTransform(bx, by);
					g.RotateTransform((float)(tblb.Angle / Math.PI * 180.0f));
					g.TranslateTransform(-bx, -by);

					g.FillEllipse(blbBrush, bx - bw / 2, by - bh / 2, bw, bh);

					g.TranslateTransform(bx, by);
					g.RotateTransform(-1 * (float)(tblb.Angle / Math.PI * 180.0f));
					g.TranslateTransform(-bx, -by);

					g.DrawString(tblb.BlobID.ToString(), font, fntBrush, new PointF(bx, by));
				}
			}
		
}

// draw the blobs
if (blobList.Count > 0) {
				lock(blobList) {
					foreach (TuioBlob tblb in blobList.Values) {
						int bx = tblb.getScreenX(width);
						int by = tblb.getScreenY(height);
						float bw = tblb.Width*width;
						float bh = tblb.Height*height;

						g.TranslateTransform(bx, by);
						g.RotateTransform((float)(tblb.Angle / Math.PI * 180.0f));
						g.TranslateTransform(-bx, -by);

						g.FillEllipse(blbBrush, bx - bw / 2, by - bh / 2, bw, bh);

						g.TranslateTransform(bx, by);
						g.RotateTransform(-1 * (float)(tblb.Angle / Math.PI * 180.0f));
						g.TranslateTransform(-bx, -by);
						
						g.DrawString(tblb.BlobID + "", font, fntBrush, new PointF(bx, by));
					}
				}
			}
		}

    private void InitializeComponent()
    {
            this.SuspendLayout();
            // 
            // TuioDemo
            // 
            this.ClientSize = new System.Drawing.Size(282, 253);
            this.Name = "TuioDemo";
            this.Load += new System.EventHandler(this.TuioDemo_Load);
            this.ResumeLayout(false);

    }

    private void TuioDemo_Load(object sender, EventArgs e)
    {

    }
    private void DrawRoundedRectangle(Graphics g, Rectangle rect, Color rectColor, int cornerRadius,Color border,int flag)
    {
        using (GraphicsPath path = new GraphicsPath())
        {
            int diameter = cornerRadius * 2;
            path.AddArc(rect.X, rect.Y, diameter, diameter, 180, 90);
            path.AddArc(rect.Right - diameter, rect.Y, diameter, diameter, 270, 90);
            path.AddArc(rect.Right - diameter, rect.Bottom - diameter, diameter, diameter, 0, 90);
            path.AddArc(rect.X, rect.Bottom - diameter, diameter, diameter, 90, 90);
            path.CloseFigure();

            // Fill the rounded rectangle
            using (SolidBrush brush = new SolidBrush(rectColor))
            {
                g.FillPath(brush, path);
            }

            if(flag==1)
            {
                // Optionally, draw a border around the rounded rectangle
                using (Pen pen = new Pen(border, 3)) // Border color and width
                {
                    g.DrawPath(pen, path);
                }
            }
         
        }
    }
    public void DrawTextBlock(Graphics g, Rectangle rect, string[] sentences, Font textFont, Brush textBrush, int verticalPadding, int horizontalPadding, int lineSpacing)
    {
        // Calculate initial Y position
        float startY = rect.Y + verticalPadding; // Adjusted to increase top space
        float maxWidth = rect.Width - (2 * horizontalPadding);
        float lineHeight = textFont.GetHeight(g) * 3; // Height for 3 lines of text

        // Set up the StringFormat to enable word wrapping
        StringFormat format = new StringFormat();
        format.Alignment = StringAlignment.Near;
        format.LineAlignment = StringAlignment.Near;
        format.FormatFlags = StringFormatFlags.LineLimit;

        foreach (string sentence in sentences)
        {
            // Draw the sentence in the specified rectangle area
            g.DrawString(sentence, textFont, textBrush, new RectangleF(rect.X + horizontalPadding, startY, maxWidth, lineHeight), format);
            startY += lineHeight + lineSpacing; // Move startY to the next block position
        }
    }

    public static void Main(String[] argv) {
	 		int port = 0;
			switch (argv.Length) {
				case 1:
					port = int.Parse(argv[0],null);
					if(port==0) goto default;
					break;
				case 0:
					port = 3333;
					break;
				default:
					Console.WriteLine("usage: mono TuioDemo [port]");
					System.Environment.Exit(0);
					break;
			}
			
			TuioDemo app = new TuioDemo(port);
			Application.Run(app);
		}
	}
